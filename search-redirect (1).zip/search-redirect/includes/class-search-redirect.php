<?php
class Search_Redirect {

    public function __construct() {

        // Enqueue CSS file
        add_action('wp_enqueue_scripts', array($this, 'enqueue_custom_search_styles'));

        // Add shortcode
        add_shortcode('custom_search', array($this, 'custom_search_shortcode'));

        // Add action for form submission
        add_action('admin_post_custom_search_redirect', array($this, 'custom_search_redirect'));
        add_action('admin_post_nopriv_custom_search_redirect', array($this, 'custom_search_redirect'));

    }

    // Enqueue CSS file
    public function enqueue_custom_search_styles() {

        wp_enqueue_style('custom-search-styles', SEARCH_REDIRECT_PATH . 'includes/css/custom-search-styles.css');

    }

    // Shortcode callback
    public function custom_search_shortcode() {

        ob_start();

        ?>
        <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
            <input type="hidden" name="action" value="custom_search_redirect">
            <input type="text" name="search_text" placeholder="Enter your search">
            <input type="submit" value="Search">
        </form>
        <?php

        return ob_get_clean();

    }

    // Form submission callback
    public function custom_search_redirect() {

        if (isset($_POST['search_text']) && !empty($_POST['search_text'])) {

            $search_text = sanitize_text_field($_POST['search_text']);
            $redirect_url = 'https://admin.relaxotranslogistics.in/ConsignmentList/ConsignmentList?ConsignmentNo=' . urlencode($search_text);
            wp_redirect($redirect_url);
            exit();

        }

    }
}
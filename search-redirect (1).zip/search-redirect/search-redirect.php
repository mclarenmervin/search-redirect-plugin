<?php
/*
Plugin Name: Search Redirect
Description: A custom search plugin with shortcode.
Version: 1.0
Author: Mervin
*/

// No direct file access
defined('ABSPATH') || exit;

define('SEARCH_REDIRECT_FILE', __FILE__);
define('SEARCH_REDIRECT_PATH', plugin_dir_path(__FILE__));

require_once SEARCH_REDIRECT_PATH . 'includes/class-search-redirect.php';

// Instantiate the class to trigger the actions and filters
new Search_Redirect();